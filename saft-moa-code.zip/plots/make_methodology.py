#!/usr/bin/env python3
"""Render the SAFT-MoA methodology diagram (left-to-right pipeline).

All text is BOLD and enlarged for readability. No in-figure title
(the caption describes the figure).

Produces ../paper/figures/fig_methodology.pdf (and .png).
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = os.path.join(os.path.dirname(__file__), "..", "paper", "figures")
os.makedirs(OUT, exist_ok=True)

# Palette
C_INPUT = "#dfe7f5"
C_PRE = "#d4efdf"
C_FEAT = "#fdebd0"
C_ENC = "#e8daef"
C_MOA = "#f5cba7"
C_FUSE = "#d6eaf8"
C_HEAD = "#f9e79f"
EDGE = "#2c3e50"

fig, ax = plt.subplots(figsize=(17, 8.2))
ax.set_xlim(0, 100)
ax.set_ylim(0, 47)
ax.axis("off")


def box(x, y, w, h, text, color, fs=13):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=0.8",
                       linewidth=2.0, edgecolor=EDGE, facecolor=color, zorder=2)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, fontweight="bold", zorder=3, wrap=True)
    return (x, y, w, h)


def arrow(p1, p2, color=EDGE, style="-|>", lw=2.2, rad=0.0):
    a = FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=22,
                        linewidth=lw, color=color, zorder=1,
                        connectionstyle=f"arc3,rad={rad}")
    ax.add_patch(a)


def r_edge(b):
    return (b[0] + b[2], b[1] + b[3] / 2)


def l_edge(b):
    return (b[0], b[1] + b[3] / 2)


# ---- Stage 1: Input -------------------------------------------------------
b_in = box(0.5, 18.5, 12.5, 9, "Roman Urdu\nSMS corpus\n(FIRE'18-\nMAPonSMS)",
           C_INPUT, fs=12.5)

# ---- Stage 2: Preprocessing ----------------------------------------------
b_pre = box(15.5, 18.5, 13.5, 9,
            "Preprocessing\n• whitespace\n• stop-words\n• tokenization",
            C_PRE, fs=12)
arrow(r_edge(b_in), l_edge(b_pre))

# ---- Stage 3: Feature families (three stacked boxes) + encoder ------------
fx = 31.5
b_char = box(fx, 33.0, 15, 7.5, "Character\nfeatures", C_FEAT, fs=13)
b_word = box(fx, 23.2, 15, 7.5, "Word\nfeatures", C_FEAT, fs=13)
b_sent = box(fx, 13.4, 15, 7.5, "Sentence\nfeatures", C_FEAT, fs=13)
b_enc = box(fx, 3.2, 15, 7.5, "Transformer\nencoder\nXLM-R (frozen)",
            C_ENC, fs=11.5)
for b in (b_char, b_word, b_sent, b_enc):
    arrow(r_edge(b_pre), l_edge(b), rad=0.0)

# ---- Stage 4: Style projector + Mixture-of-Adapters -----------------------
sx = 50
b_proj = box(sx, 23.2, 13, 7.5, "Style\nprojector\nMLP → s", C_FUSE, fs=12)
for b in (b_char, b_word, b_sent):
    arrow(r_edge(b), l_edge(b_proj), rad=-0.05)

mx = 66
b_a1 = box(mx, 34.0, 14, 5.6, "Adapter: char", C_MOA, fs=12.5)
b_a2 = box(mx, 27.0, 14, 5.6, "Adapter: word", C_MOA, fs=12.5)
b_a3 = box(mx, 20.0, 14, 5.6, "Adapter: sent.", C_MOA, fs=12.5)
b_gate = box(mx, 12.6, 14, 5.6, "Gate g(h,s)\nsoftmax", C_MOA, fs=12.5)
arrow(r_edge(b_enc), (mx, 14.5), rad=0.15)
for b in (b_a1, b_a2, b_a3):
    arrow(r_edge(b_proj), l_edge(b), rad=0.05)
arrow(r_edge(b_proj), l_edge(b_gate), rad=-0.05)
ax.text(mx + 7, 41.2, "Mixture-of-Adapters (MoA)", ha="center", fontsize=14,
        fontstyle="italic", fontweight="bold")

# ---- Stage 5: Fusion ------------------------------------------------------
gx = 82.5
b_fuse = box(gx, 18.5, 13, 9, "Gated\nresidual\nfusion", C_FUSE, fs=12.5)
for b in (b_a1, b_a2, b_a3, b_gate):
    arrow(r_edge(b), l_edge(b_fuse), rad=0.05)

# ---- Stage 6: Heads + output ---------------------------------------------
b_age = box(89.5, 30.0, 9.5, 7.0, "Age\nhead", C_HEAD, fs=12.5)
b_gen = box(89.5, 9.5, 9.5, 7.0, "Gender\nhead", C_HEAD, fs=12.5)
arrow(r_edge(b_fuse), l_edge(b_age), rad=0.18)
arrow(r_edge(b_fuse), l_edge(b_gen), rad=-0.18)
ax.text(94.25, 37.8, "{15-19, 20-24, 25+}", ha="center", fontsize=11,
        fontweight="bold")
ax.text(94.25, 7.0, "{male, female}", ha="center", fontsize=11,
        fontweight="bold")

# ---- Stage banner labels (left-to-right) ----------------------------------
banner_y = 44.6
for x, t in [(6.7, "1. Input"), (22.2, "2. Preprocess"),
             (38.0, "3. Features & encoding"), (56.5, "4. Projection"),
             (73.0, "5. MoA routing"), (86.0, "6. Fusion"),
             (94.3, "7. Predict")]:
    ax.text(x, banner_y, t, ha="center", fontsize=13, fontweight="bold",
            color="#34495e")

fig.tight_layout()
path = os.path.join(OUT, "fig_methodology.pdf")
fig.savefig(path, bbox_inches="tight")
fig.savefig(path.replace(".pdf", ".png"), bbox_inches="tight", dpi=170)
plt.close(fig)
print("wrote", path)
