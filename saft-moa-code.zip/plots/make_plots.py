#!/usr/bin/env python3
"""Generate all figures for the SAFT-MoA paper.

All numbers are HARD-CODED here (mirroring saft_moa/paper_results.py) so the
figures can be regenerated standalone without running the experiments.

DESIGN NOTES:
- No in-figure titles (titles live in the LaTeX captions).
- All text is BOLD and enlarged for readability at print size.
- Model names on x-axes use short codes M1..M9; the mapping is:
      M1=NB, M2=NB Updatable, M3=J48, M4=KNN, M5=RF,
      M6=CHIRP, M7=AdaBoostM1, M8=ABMRF, M9=SAFT-MoA
  (state this in each figure caption).

Outputs (PDF + PNG) into ../paper/figures/ .
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 16,
    "font.family": "serif",
    "font.weight": "bold",
    "axes.titleweight": "bold",
    "axes.labelweight": "bold",
    "axes.labelsize": 18,
    "axes.titlesize": 18,
    "xtick.labelsize": 15,
    "ytick.labelsize": 15,
    "legend.fontsize": 15,
    "axes.linewidth": 1.3,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linestyle": "--",
    "figure.dpi": 150,
    "savefig.bbox": "tight",
})

OUT = os.path.join(os.path.dirname(__file__), "..", "paper", "figures")
os.makedirs(OUT, exist_ok=True)

MODELS = ["NB", "NB Updatable", "J48", "KNN", "RF", "CHIRP", "AdaBoostM1",
          "ABMRF", "SAFT-MoA"]
# short codes for the x-axis (defined in the caption)
MCODES = [f"M{i+1}" for i in range(len(MODELS))]   # M1 .. M9
REGIMES = ["character", "word", "sentence", "combination"]

# ---- HARD-CODED accuracies (%) --------------------------------------------
AGE_ACC = {
    "character":   [48.57, 49.14, 50.29, 42.00, 53.14, 39.43, 43.71, 54.00, 58.86],
    "word":        [49.14, 49.43, 46.29, 44.00, 50.29, 38.57, 48.00, 50.57, 55.43],
    "sentence":    [40.57, 40.29, 43.43, 41.40, 47.43, 39.14, 46.86, 49.71, 54.00],
    "combination": [50.57, 49.71, 51.43, 41.42, 55.14, 40.00, 51.71, 56.28, 61.71],
}
GENDER_ACC = {
    "character":   [72.00, 72.57, 75.14, 63.71, 73.43, 75.71, 75.14, 74.57, 78.29],
    "word":        [56.57, 57.14, 56.00, 58.86, 60.00, 58.57, 59.71, 60.00, 66.29],
    "sentence":    [56.00, 56.00, 55.43, 57.14, 60.00, 57.43, 60.00, 62.00, 67.43],
    "combination": [72.57, 72.00, 71.43, 68.29, 74.57, 39.82, 71.71, 73.14, 79.43],
}

# combination-regime full metrics for the proposed vs strongest baselines
COMB_METRICS = {
    "age": {  # precision, recall, f1, mcc, accuracy
        "RF":       [0.660, 0.551, 0.560, 0.230, 0.5514],
        "ABMRF":    [0.681, 0.563, 0.566, 0.254, 0.5628],
        "SAFT-MoA": [0.712, 0.618, 0.641, 0.312, 0.6171],
    },
    "gender": {
        "RF":       [0.760, 0.746, 0.745, 0.459, 0.7457],
        "ABMRF":    [0.745, 0.731, 0.730, 0.430, 0.7314],
        "SAFT-MoA": [0.792, 0.776, 0.784, 0.512, 0.7943],
    },
}

# Percentage difference of SAFT-MoA vs each baseline (combination regime)
PD_AGE = [19.84, 21.54, 18.17, 39.35, 11.25, 42.69, 17.63, 9.20]
PD_GENDER = [9.03, 9.81, 10.61, 15.08, 6.31, 66.43, 10.22, 8.25]
# baselines only (no SAFT-MoA) -> M1..M8
PD_CODES = [f"M{i+1}" for i in range(8)]

# Ablation: SAFT-MoA combination accuracy with components removed
ABLATION = {
    "code":  ["A1", "A2", "A3", "A4", "A5", "A6"],
    "label": ["Full SAFT-MoA", "w/o MoA gate", "w/o style fusion",
              "w/o char adapter", "w/o preprocessing", "Backbone only"],
    "age":    [61.71, 59.10, 58.20, 57.85, 57.40, 54.60],
    "gender": [79.43, 77.10, 76.20, 75.90, 75.10, 72.80],
}

COLORS = plt.cm.tab10(np.linspace(0, 1, 10))
PROP_COLOR = "#c0392b"
BASE_COLOR = "#34618e"


def _bold_ticks(ax):
    for lbl in ax.get_xticklabels() + ax.get_yticklabels():
        lbl.set_fontweight("bold")


def _bar(ax, codes, names, vals, ylabel, ymin=35):
    colors = [PROP_COLOR if n == "SAFT-MoA" else BASE_COLOR for n in names]
    bars = ax.bar(range(len(codes)), vals, color=colors, edgecolor="black",
                  linewidth=1.0)
    ax.set_xticks(range(len(codes)))
    ax.set_xticklabels(codes, fontsize=15, fontweight="bold")
    ax.set_ylabel(ylabel, fontweight="bold")
    ax.set_ylim(ymin, max(vals) + 7)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.5, f"{v:.1f}",
                ha="center", va="bottom", fontsize=12, fontweight="bold")
    _bold_ticks(ax)
    return bars


def fig_accuracy(acc_dict, target):
    # 2x2 grid of regimes, NO titles (caption handles it)
    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    for ax, reg in zip(axes.flat, REGIMES):
        _bar(ax, MCODES, MODELS, acc_dict[reg], "Accuracy (%)")
        # small bold corner annotation to identify the regime panel
        ax.text(0.02, 0.95, f"({reg})", transform=ax.transAxes,
                fontsize=14, fontweight="bold", va="top", ha="left",
                bbox=dict(boxstyle="round,pad=0.25", fc="white",
                          ec="#888", alpha=0.8))
    fig.tight_layout()
    path = os.path.join(OUT, f"fig_{target}_accuracy.pdf")
    fig.savefig(path); fig.savefig(path.replace(".pdf", ".png"))
    plt.close(fig)
    print("wrote", path)


def fig_combination_metrics():
    metrics = ["Precision", "Recall", "F1", "MCC", "Accuracy"]
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    for ax, target in zip(axes, ["age", "gender"]):
        data = COMB_METRICS[target]
        models = list(data.keys())
        x = np.arange(len(metrics))
        w = 0.25
        for i, m in enumerate(models):
            color = PROP_COLOR if m == "SAFT-MoA" else COLORS[i + 3]
            ax.bar(x + (i - 1) * w, data[m], w, label=m, color=color,
                   edgecolor="black", linewidth=0.9)
        ax.set_xticks(x)
        ax.set_xticklabels(metrics, fontsize=14, fontweight="bold", rotation=15)
        ax.set_ylabel("Score", fontweight="bold")
        ax.set_ylim(0, 1.05)
        ax.text(0.02, 0.96, f"({target})", transform=ax.transAxes,
                fontsize=15, fontweight="bold", va="top", ha="left",
                bbox=dict(boxstyle="round,pad=0.25", fc="white",
                          ec="#888", alpha=0.8))
        ax.legend(fontsize=14, prop={"weight": "bold"})
        _bold_ticks(ax)
    fig.tight_layout()
    path = os.path.join(OUT, "fig_combination_metrics.pdf")
    fig.savefig(path); fig.savefig(path.replace(".pdf", ".png"))
    plt.close(fig)
    print("wrote", path)


def fig_pd(pd_vals, target):
    fig, ax = plt.subplots(figsize=(9, 5.2))
    bars = ax.bar(range(len(PD_CODES)), pd_vals, color="#2c7fb8",
                  edgecolor="black", linewidth=1.0)
    ax.set_xticks(range(len(PD_CODES)))
    ax.set_xticklabels(PD_CODES, fontsize=15, fontweight="bold")
    ax.set_ylabel("Percentage difference (%)", fontweight="bold")
    ax.set_ylim(0, max(pd_vals) + 6)
    for b, v in zip(bars, pd_vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.5, f"{v:.1f}",
                ha="center", va="bottom", fontsize=13, fontweight="bold")
    _bold_ticks(ax)
    fig.tight_layout()
    path = os.path.join(OUT, f"fig_pd_{target}.pdf")
    fig.savefig(path); fig.savefig(path.replace(".pdf", ".png"))
    plt.close(fig)
    print("wrote", path)


def fig_ablation():
    fig, ax = plt.subplots(figsize=(10, 5.6))
    x = np.arange(len(ABLATION["code"]))
    w = 0.38
    ax.bar(x - w / 2, ABLATION["age"], w, label="Age", color="#e67e22",
           edgecolor="black", linewidth=0.9)
    ax.bar(x + w / 2, ABLATION["gender"], w, label="Gender", color="#16a085",
           edgecolor="black", linewidth=0.9)
    ax.set_xticks(x)
    ax.set_xticklabels(ABLATION["code"], fontsize=15, fontweight="bold")
    ax.set_ylabel("Accuracy (%)", fontweight="bold")
    ax.set_ylim(50, 86)
    ax.legend(fontsize=15, prop={"weight": "bold"})
    for i in x:
        ax.text(i - w / 2, ABLATION["age"][i] + 0.4, f"{ABLATION['age'][i]:.1f}",
                ha="center", fontsize=12, fontweight="bold")
        ax.text(i + w / 2, ABLATION["gender"][i] + 0.4,
                f"{ABLATION['gender'][i]:.1f}", ha="center", fontsize=12,
                fontweight="bold")
    _bold_ticks(ax)
    fig.tight_layout()
    path = os.path.join(OUT, "fig_ablation.pdf")
    fig.savefig(path); fig.savefig(path.replace(".pdf", ".png"))
    plt.close(fig)
    print("wrote", path)


def fig_heatmap():
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    for ax, (target, acc) in zip(axes, [("age", AGE_ACC), ("gender", GENDER_ACC)]):
        mat = np.array([acc[r] for r in REGIMES])  # 4 x 9
        im = ax.imshow(mat, aspect="auto", cmap="YlGnBu")
        ax.set_xticks(range(len(MCODES)))
        ax.set_xticklabels(MCODES, fontsize=14, fontweight="bold")
        ax.set_yticks(range(len(REGIMES)))
        ax.set_yticklabels([r.capitalize() for r in REGIMES],
                           fontsize=14, fontweight="bold")
        ax.text(0.01, 1.06, f"({target})", transform=ax.transAxes,
                fontsize=15, fontweight="bold", va="bottom", ha="left")
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                ax.text(j, i, f"{mat[i, j]:.0f}", ha="center", va="center",
                        fontsize=12, fontweight="bold",
                        color="white" if mat[i, j] > 62 else "black")
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cb.ax.tick_params(labelsize=12)
        for t in cb.ax.get_yticklabels():
            t.set_fontweight("bold")
        _bold_ticks(ax)
    fig.tight_layout()
    path = os.path.join(OUT, "fig_heatmap_accuracy.pdf")
    fig.savefig(path); fig.savefig(path.replace(".pdf", ".png"))
    plt.close(fig)
    print("wrote", path)


def main():
    fig_accuracy(AGE_ACC, "age")
    fig_accuracy(GENDER_ACC, "gender")
    fig_combination_metrics()
    fig_pd(PD_AGE, "age")
    fig_pd(PD_GENDER, "gender")
    fig_ablation()
    fig_heatmap()
    print("All figures written to", os.path.abspath(OUT))


if __name__ == "__main__":
    main()
